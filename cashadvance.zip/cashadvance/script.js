function applyNow() {
  window.location.href = "mailto:adonsea1@gmail.com?subject=Cash%20Advance%20Inquiry";
}
